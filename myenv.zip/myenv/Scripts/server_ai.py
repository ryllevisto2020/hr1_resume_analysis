from flask import Flask
from flask import request

from google import genai
from pydantic import BaseModel

from pypdf import PdfReader

import json

app = Flask(__name__)

class ResumeAnalysis(BaseModel):
    percentage:int
    
class PreInterviewQuestion(BaseModel):
    question:str
    choice:list[str]
    answer:str

@app.route("/resume/analysis",methods=['GET','POST'])
def resume_analysis():
    
    job_desc = request.form.get('description')
    
    f = request.files.get('file')
    o = open(request.files['file'].filename, 'wb')
    for item in f:
        o.write(item)
    o.close()
    
    client = genai.Client(api_key="AIzaSyAGYuIhuTyWhSKB0XE_I6RIOmNvma3OqaI")
    
    reader = PdfReader(request.files['file'].filename)
    
    pages = reader.pages[0]
    
    text = pages.extract_text()
    
    response = client.models.generate_content(
        model="gemini-2.0-flash",
        contents="Rate this Resume"+ text+ "based on the Job Requirements and Qualifications"+ job_desc,
        config={
            'response_mime_type': 'application/json',
            'response_schema': ResumeAnalysis,
            },
        )
    percentage = json.loads(response.text)
    return response.text

@app.route("/pre-assessment/<title>",methods=['GET','POST'])
def pre_assessment(title):
    
    client = genai.Client(api_key="AIzaSyAGYuIhuTyWhSKB0XE_I6RIOmNvma3OqaI")
    response = client.models.generate_content(
        model="gemini-2.0-flash",
        contents="Give me 10 Question with 4 multiple Choice "+title+" tourism with correct answer",
        config={
            'response_mime_type': 'application/json',
            'response_schema': list[PreInterviewQuestion],
            },
        )
    
    return response.text